import SwiftUI

// MARK: - Model
struct AdventureOption {
    let description: String
    let choices: [String: AdventureOption]?
    let ending: String?
    let imageName: String?
    
    init(description: String, choices: [String: AdventureOption]? = nil, ending: String? = nil, imageName: String? = nil) {
        self.description = description
        self.choices = choices
        self.ending = ending
        self.imageName = imageName
    }
}

// MARK: - View
struct ContentView: View {
    var body: some View {
        NavigationView {
            AdventureView(adventureOption: myAdventure)
        }
    }
}

struct AdventureView: View {
    let adventureOption: AdventureOption
    
    var body: some View {
        VStack {
            // Image displayed based on adventure chosen
            if adventureOption.description == "Choose your adventure: Hogadon Ski Resort" {
                Image("Mountain") // First page image
            } else if adventureOption.description == "Choose a slope:" {
                Image("SkiDude") // Ski choices image
            } else if adventureOption.description == "Choose an activity at the lodge:" {
                Image("SkiLodge") // Lodge choices image
            } else {
               
            }
            
           

        
            if let choices = adventureOption.choices {
                List(choices.keys.sorted(), id: \.self) { choice in
                    if let nextStep = choices[choice] {
                        NavigationLink(destination: AdventureView(adventureOption: nextStep)) {
                            Text(choice)
                        }
                    }
                }
            }
            
            else if let ending = adventureOption.ending, let imageName = adventureOption.imageName {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 200)
                Text(ending)
            }
        }
        .navigationTitle(adventureOption.description)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Adventure Setup
let myAdventure = AdventureOption(description: "Choose your adventure: Hogadon Ski Resort", choices: [
    "Ski": AdventureOption(description: "Choose a slope:", choices: [
        "Bunny Hill": AdventureOption(description: "Bunny Hill", ending: "You enjoyed a nice relaxing day of skiing on the bunny slopes! :)", imageName: "BunnyHill"),
        "Black Diamond": AdventureOption(description: "Black Diamond", ending: "You broke your arm and ski patrol had to escort you off the mountain :(", imageName: "BlackDiamond")
    ]),
    "Lodge": AdventureOption(description: "Choose an activity at the lodge:", choices: [
        "Study for an Exam": AdventureOption(description: "Study for an Exam", ending: "You got an A on your exam, good job studying!", imageName: "Study"),
        "Have a Beer": AdventureOption(description: "Have a Beer", ending: "Beer by the fire, cheers!", imageName: "Beer")
    ])
])


// MARK: - App Entry Point
@main
struct MyAdventureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

